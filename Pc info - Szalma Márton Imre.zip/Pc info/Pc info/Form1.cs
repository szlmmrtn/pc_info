﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Pc_info
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
            //összes infó összeszedése

            var cpukey = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0\");
            string cpu = cpukey.GetValue("ProcessorNameString").ToString();

            var pckey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\HardwareConfig\Current\");
            string pc = pckey.GetValue("SystemProductName").ToString();
 

            label1.Text += cpu;
            label2.Text += pc;
            label8.Text = ("Welcome " + Environment.UserName);

        }

        private void item_refresh()
        {
            //összes infó összeszedése
            PerformanceCounter mem = new PerformanceCounter("Memory", "% Committed Bytes In Use");
            PerformanceCounter cpucpu = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            PerformanceCounter ramCounter = new PerformanceCounter("Memory", "Available MBytes");

            float valuecpu = cpucpu.NextValue();
            float valuemem = mem.NextValue();
            progressBar1.Value = 0;

            progressBar1.Maximum = 100;
            progressBar1.Step = 1;
            progressBar1.Value = Convert.ToInt32(valuemem);

            System.Threading.Thread.Sleep(100);
            valuecpu = cpucpu.NextValue();

            progressBar2.Maximum = 100;
            progressBar2.Step = 1;
            progressBar2.Value = Convert.ToInt32(valuecpu);

            label5.Text = (Convert.ToInt32(valuecpu)+ "%");
            label6.Text = (Convert.ToInt32(valuemem) + "%");
            label7.Text = ("RAM usage in mb: " + ramCounter.NextValue().ToString() + "Mb") ;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //információ frissítése gombnyomásra
            item_refresh();
        }
    }
}
